var ChoiceNumber = 3;

function ajouterChoix(){
    var placeholder = "Choix " + ChoiceNumber;
    var newChoice = document.createElement("input");
    newChoice.setAttribute("type","text");
    newChoice.setAttribute("class","form-control");
    newChoice.setAttribute("id","prediChoicesBox");
    newChoice.setAttribute("name","choices[]");
    newChoice.setAttribute("placeholder",placeholder);
    newChoice.setAttribute("required","required");
    document.getElementById("choices").appendChild(newChoice);
    ChoiceNumber++;
};