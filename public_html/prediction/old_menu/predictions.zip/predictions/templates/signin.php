<?php

// Si la page est appelée directement par son adresse, on redirige en passant pas la page index
if (basename($_SERVER["PHP_SELF"]) != "index.php")
{
	header("Location:../index.php?view=login");
	die("");
}
?>

<div class="page-header">
	<h1>Connexion</h1>
</div>

<p class="lead">

 <form role="form" action="controleur.php">
  <div class="form-group">
    <label for="usernameBox">Nom d'utilisateur</label>
    <input type="text" class="form-control" id="usernameBox" name="username" required="required">
  </div>
  <div class="form-group">
    <label for="passwordBox">Mot de passe</label>
    <input type="password" class="form-control" id="passwordBox" name="password" required="required">
  </div>
  <button type="submit" name="action" value="Connexion" class="btn btn-default">Connexion</button>
</form>

</p>




