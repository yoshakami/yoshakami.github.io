<?php
if (basename($_SERVER["PHP_SELF"]) != "index.php")
{
	header("Location:../index.php?view=accueil");
	die("");
}
?>
    <div class="page-header">
      <h1>Créer une nouvelle prédiction</h1>
    </div>

    <p class="lead">
      <form action="controleur.php">
        <div class="form-group">
          <label for="prediNameBox">Question</label>
          <input type="text" class="form-control" id="prediNameBox" name="name" required="required">
        </div>
        <div class="form-group">
          <label for="prediEndBox">Fin des votes</label>
          <input type="datetime-local" class="form-control" id="prediEndBox" name="end" required="required">
        </div>
        <div id="choices">
          <label for="prediChoicesBox">Choix</label>
          <input type="button" class="btn btn-default" value="Ajouter un choix" onclick="ajouterChoix();">
          <input type="text" class="form-control" id="prediChoicesBox" name="choices[]" placeholder="Choix 1" required="required">
          <input type="text" class="form-control" id="prediChoicesBox" name="choices[]" placeholder="Choix 2" required="required">
        </div>
        <button type="submit" name="action" value="Publier" class="btn btn-default">Publier</button>


      </form>
    </p>

