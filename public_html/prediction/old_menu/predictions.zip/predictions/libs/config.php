<?php

$BDD_host="localhost";
$BDD_user="root";
$BDD_password="mysql"; // vide sous windows
$BDD_base="2iMVC";

?>
