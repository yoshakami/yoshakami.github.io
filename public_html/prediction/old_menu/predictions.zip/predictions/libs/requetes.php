<?php

include_once "maLibSQL.pdo.php";

function creerCompte($username,$displayname,$hash){
    $SQL = "INSERT INTO users VALUES ('$username','$displayname','$hash',NULL,100,false,NOW())";
    SQLInsert($SQL);
    $_SESSION["user"] = $username;
    $_SESSION["nickname"] = SQLGetChamp("SELECT nickname FROM users WHERE username='$username';");
	$_SESSION["connecte"] = true;
	$_SESSION["heureConnexion"] = date("H:i:s");
}

function seConnecter($username,$password){
    $SQL="SELECT hash_pwd FROM users WHERE username='$username';";
    $hash_saved=SQLGetChamp($SQL);
    if(password_verify($password,$hash_saved)){
        $_SESSION["user"] = $username;
        $_SESSION["nickname"] = SQLGetChamp("SELECT nickname FROM users WHERE username='$username';");
	    $_SESSION["connecte"] = true;
	    $_SESSION["heureConnexion"] = date("H:i:s");
        $SQL="UPDATE users SET lastConnection = NOW() WHERE username = '$username';";
        SQLUpdate($SQL);
    }
}

function creerPrediction($name,$user,$endDate,$choix){//La variable choix sera un tableau créé pour l'occasion (format : "choix1", "choix2", "choix3", etc.)
    $SQL = "INSERT INTO predictions VALUES (DEFAULT,'$name','$user',DEFAULT,'$endDate',NULL);";
    SQLInsert($SQL);
    $predictionID = SQLGetChamp("SELECT id FROM predictions WHERE title = '$name' AND author = '$user' AND endDate = '$endDate';");
    foreach($choix as $unChoix){
        $SQL = "INSERT INTO predictionChoices VALUES (DEFAULT, $predictionID, '$unChoix');";
    }
}

function parier($user,$prediction,$choice,$points){
    $SQL = "BEGIN TRANSACTION;
            INSERT INTO usersChoices VALUES ('$user',$prediction,$choice,$points);
            UPDATE users SET points = points - $points WHERE username = '$user';
            COMMIT;";
    SQLInsert($SQL);
}

function donnerReponsePrediction($prediction,$answer){
    $SQL = "UPDATE predictions SET correctAnswer = $answer WHERE id = $prediction;";
    //Il ne faut pas oublier de mettre à jour les points en conséquence 
}

?>