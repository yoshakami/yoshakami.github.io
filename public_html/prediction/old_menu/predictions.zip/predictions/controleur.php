<?php
session_start();

	include_once "libs/maLibUtils.php";
	include_once "libs/maLibSQL.pdo.php";
	include_once "libs/maLibSecurisation.php"; 
	include_once "libs/modele.php";
	include_once "libs/requetes.php";

	$addArgs = "";

	if ($action = valider("action"))
	{
		ob_start ();
		echo "Action = '$action' <br />";
		switch($action)
		{
			case 'Connexion' : //Obligé d'utiliser password_verification : on met dans le modèle
				seConnecter($_REQUEST["username"],$_REQUEST["password"]);
			break;
			
			case 'Inscription' :
				if($_REQUEST["username"] && $_REQUEST["displayname"] && $_REQUEST["password"] && $_REQUEST["passwordconfirmation"] && ($_REQUEST["password"] == $_REQUEST["passwordconfirmation"])){
					$hash = password_hash($_REQUEST["password"],PASSWORD_DEFAULT);
					creerCompte($_REQUEST["username"],$_REQUEST["displayname"],$hash);
				}
				// On redirigera vers la page index automatiquement
			break;

			case 'Publier' :
				if($_REQUEST["name"] && $_REQUEST["end"] && $_REQUEST["choices[]"]){
					creerPrediction($_REQUEST["name"],$_SESSION["user"],$_REQUEST["end"],$_REQUEST["choices[]"]);
				}
			break;

			case 'Logout' :
				session_destroy();
			break;

		}

	}

	// On redirige toujours vers la page index, mais on ne connait pas le répertoire de base
	// On l'extrait donc du chemin du script courant : $_SERVER["PHP_SELF"]
	// Par exemple, si $_SERVER["PHP_SELF"] vaut /chat/data.php, dirname($_SERVER["PHP_SELF"]) contient /chat

	$urlBase = dirname($_SERVER["PHP_SELF"]) . "/index.php";
	// On redirige vers la page index avec les bons arguments

	header("Location:" . $urlBase . $addArgs);

	// On écrit seulement après cette entête
	ob_end_flush();
	
?>










