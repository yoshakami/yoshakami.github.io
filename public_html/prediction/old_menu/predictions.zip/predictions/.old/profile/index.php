<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profile.css">
    <title>Mon profil</title>
</head>
<body>
    <div class="navbar">Navbar</div>
    <div class="profile">
        <hr>
        <div class="name"><?php echo($_GET["displayname"] <br> $_GET["username"]); ?></div>
        <div class="select">Prédictions créées par DisplayName / Prédictions auxquelles DisplayName a participé</div>
    </div>
    <div class="details">Détails</div>
</body>
</html>