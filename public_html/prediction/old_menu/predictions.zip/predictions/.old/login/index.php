<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
    <meta charset="latin-1">
</head>
<body>
<form action="index.php" method="post">
    <h2>login</h2>
    <?php if (isset($_GET['error'])) { ?>
        <p class="error"><?php echo $_GET['error']; ?></p>
    <?php } ?>
    <label class="display-name">Display Name</label>
    <input class="display-input" type="text" name="dname" placeholder="Display Name"><br>
    <label class="user-name">User Name</label>
    <input class="user-input" type="text" name="uname" placeholder="User Name">
    <p class="user-note">⬅ (only used to login)</p><br>
    <label class="password-name">Password</label>
    <input class="password-input" type="password" name="password" placeholder="Password"><br>
    <button class="submit-button" type="submit">Login</button>
</form>
</body>
<?php


include "../../txt/database_param.php";

function split($text)
{
    $a = [];
    $word = 0;
    for ($i = 0; $i < strlen($text); $i++) {
        if ($text[$i] != "\n") {
            $a[$word] += $text[$i];
        } else {
            $word += 1;
        }
    }
    return $a;
}

if (isset($_POST['dname']) && isset($_POST['uname']) && isset($_POST['password'])) {

    function validate($data)
    {

        $data = trim($data);

        $data = stripslashes($data);

        $data = htmlspecialchars($data);

        return $data;

    }

    $uname = validate($_POST['uname']);
    $dname = validate($_POST['dname']);
    $pass = validate($_POST['password']);

    if (empty($uname)) {
        header("Location: index.php?error=Username");
        exit();

    } else if (empty($dname)) {
        header("Location: index.php?error=DisplayName");
        exit();
    } else if (empty($pass)) {
        header("Location: index.php?error=Password");
        exit();
    } else {
        $sql = "SELECT * FROM users WHERE username='$uname' AND password='$pass' AND nickname='$dname'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['nickname'] === $dname && $row['username'] === $uname && $row['password'] === $pass) {

                echo "Logged in!";

                $_SESSION['user_name'] = $row['user_name'];

                $_SESSION['name'] = $row['name'];

                $_SESSION['id'] = $row['id'];

                header("Location: home.html");

                exit();
            }
        }
    }
}